http://ajax.microsoft.com/ajax/4.0/1/MicrosoftAjax.debug.js
http://ajax.microsoft.com/ajax/4.0/1/MicrosoftAjaxTimer.debug.js
http://ajax.microsoft.com/ajax/4.0/1/MicrosoftAjaxWebForms.debug.js
