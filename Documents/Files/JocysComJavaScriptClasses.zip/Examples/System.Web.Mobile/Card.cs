﻿namespace JocysCom.WebSites.WebApp.Scripts.Classes.Examples
{
	public class Card
	{
		public string Type { get; set; }
		public string Name { get; set; }
		public string Number { get; set; }
		public string ValidFrom { get; set; }
		public string ExpiresEnd { get; set; }
		public string EncryptedData { get; set; }
		public string EncryptedPass { get; set; }
	}
}