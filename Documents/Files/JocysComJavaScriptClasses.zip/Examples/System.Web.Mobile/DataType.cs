﻿namespace JocysCom.WebSites.WebApp.Scripts.Classes.Examples
{
	public enum DataType
	{
		None = 0,
		GetRsaKey = 1,
		SendProfile = 2,
	}

}
