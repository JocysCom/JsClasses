//=============================================================================
// Jocys.com JavaScript.NET Classes               (In C# Object Oriented Style)
// Created by Evaldas Jocys <evaldas@jocys.com>
//-----------------------------------------------------------------------------
// Jocys.com Password Generator         www.jocys.com/Scripts/Classes/Documents
//-----------------------------------------------------------------------------

To run password generator as HTML page:
  
	Scripts\Classes\Examples\System.Security.Password.htm
	
To run password generator as Windows application create shortcut to:
  
	Scripts\Classes\Examples\System.Security.Password.hta

	Icon for windows shortcut:

	Scripts\Classes\System.Security.Password\Images\Icons\PassGen.ico