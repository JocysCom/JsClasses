# JsClasses
Object Oriented JavaScript Class Library in C#/.NET Style

https://www.codeproject.com/kb/tips/JocysComJavaScriptClasses.aspx
